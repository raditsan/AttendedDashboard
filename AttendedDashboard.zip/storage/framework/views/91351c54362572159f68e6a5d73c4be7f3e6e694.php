<?php $__env->startSection('pageTitle', 'Dashboard'); ?>
<?php $__env->startSection('pageDescription', 'Report'); ?>
<?php $__env->startSection('pageLevel', 'Dashboard'); ?>
<?php $__env->startSection('pageActive', 'Report'); ?>
<?php $__env->startSection('content'); ?>
    <section class="content">
        <!-- Info boxes -->
        <div class="row">
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo e($totals->count()); ?></h3>

                        <p> Employee Total</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person-add"></i>
                    </div>
                    <a href="<?php echo e(route('EmployeeData')); ?>" class="small-box-footer">
                      More info  <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>

            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo e($total_login_today->count()); ?></h3>

                        <p>Today Login</p>
                    </div>
                    <div class="icon">
                        <i class="ion fa-calendar-times-o "></i>
                    </div>
                    <a href="#" class="small-box-footer">
                        More info <i class="fa fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>