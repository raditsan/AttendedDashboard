<?php

return [

    'attended' => 'Attended',
    'attended_description' => 'Make sure you are attended today.',

];
