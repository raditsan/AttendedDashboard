
    <ul class="sidebar-menu" data-widget="tree">
        <li class="header">HEADER</li>
        <!-- Optionally, you can add icons to the links -->
        <li class="<?php if(\Request::is('home','/')): ?> active <?php endif; ?>"><a href="/home"><i class="fa fa-link"></i> <span>Report</span></a></li>
        <li class="treeview <?php if(\Request::is('employee_data','attended_master')): ?> active <?php endif; ?>">
            <a href="#">
                <i class="fa fa-link"></i> <span>Master Data</span>
                <span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span>
            </a>
            <ul class="treeview-menu">
                <li class="<?php if(\Request::is('employee_data')): ?> active <?php endif; ?>"><a href="<?php echo e(route('EmployeeData')); ?>">Employee Data</a></li>
                <li class="<?php if(\Request::is('attended_master')): ?> active <?php endif; ?>"><a href="<?php echo e(route('AttendedMaster')); ?>">Attended Master</a></li>
            </ul>
        </li>
    </ul>