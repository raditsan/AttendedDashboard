<?php $__env->startSection('pageTitle', 'Master Data'); ?>
<?php $__env->startSection('pageDescription', 'Attended Master'); ?>
<?php $__env->startSection('pageLevel', 'Master'); ?>
<?php $__env->startSection('pageActive', 'Attended Master'); ?>
<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Attended Data</h3>

                <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="" data-original-title="Collapse">
                        <i class="fa fa-minus"></i></button>
                    <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="" data-original-title="Remove">
                        <i class="fa fa-times"></i></button>
                </div>
            </div>
            <div class="box-body" style="">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <td>Date</td>
                        <td>Email</td>
                        <td>Day</td>
                        <td>In</td>
                        <td>Out</td>
                        <td>working hours</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $data_attended; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(date("Y-m-d", strtotime($dt->login_time))); ?></td>
                            <td><?php echo e($dt->email); ?></td>
                            <td><?php echo e(date("l", strtotime($dt->login_time))); ?></td>
                            <td><?php echo e(date("H:i:s", strtotime($dt->login_time))); ?></td>
                            <td>
                                <?php if(!empty($dt->signout_time)): ?>
                                    <?php echo e(date("H:i:s", strtotime($dt->signout_time))); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(!empty($dt->signout_time)): ?>
                                    <?php 
                                        $t1 = strtotime($dt->login_time);
                                            $t2 = strtotime($dt->signout_time);
                                            $delta_T = ($t2 - $t1);
                                            $day = round(($delta_T % 604800) / 86400);
                                            $hours = round((($delta_T % 604800) % 86400) / 3600);
                                            $minutes = round(((($delta_T % 604800) % 86400) % 3600) / 60);
                                            $sec = round((((($delta_T % 604800) % 86400) % 3600) % 60));
                                            //echo $day." days";
                                            echo $hours." hours ";
                                            echo $minutes." minutes ";
                                            echo $sec." sec";

                                     ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>


                </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer" style="">

            </div>
            <!-- /.box-footer-->
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>