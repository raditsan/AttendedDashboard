<?php $__env->startSection('pageTitle', 'Profile'); ?>
<?php $__env->startSection('pageDescription', ''); ?>
<?php $__env->startSection('pageLevel', 'Profile'); ?>
<?php $__env->startSection('pageActive', 'here'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">

    <div class="center-block">
        <div class="col-lg-3 col-lg-offset-4">

            <!-- Profile Image -->
            <div class="box box-primary">
                <div class="box-body box-profile">
                    <img class="profile-user-img img-responsive img-circle" src="<?php echo e(URL::asset('img_profile/' . Auth::user()->img_profile)); ?>" alt="User profile picture">

                    <h3 class="profile-username text-center"><?php echo e(Auth::user()->name); ?></h3>

                    <p class="text-muted text-center"><?php echo e(Auth::user()->rule); ?></p>

                    <ul class="list-group list-group-unbordered">
                        <li class="list-group-item">
                            <b>Email</b> <a class="pull-right"><?php echo e(Auth::user()->email); ?></a>
                        </li>
                        <li class="list-group-item">
                            <b>Join date</b> <a class="pull-right"><?php echo e(Auth::user()->created_at); ?></a>
                        </li>
                        <li class="list-group-item">
                            <b>Rule</b> <a class="pull-right"><?php echo e(Auth::user()->rule); ?></a>
                        </li>
                    </ul>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>