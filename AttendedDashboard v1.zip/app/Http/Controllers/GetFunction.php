<?php

namespace App\Http\Controllers;

use App\AttendedModel;
use Illuminate\Http\Request;

class GetFunction extends Controller
{
    public function pageProfile(){
        return view('profile');
    }
    //
    public function getTimeserver(){
        $dates = date("D M d Y H:m:s O");
        return $dates;
    }

    public function getIpclient(){
        $ip = \Request::ip();
        return $ip;
    }

    public function employIn(Request $request) {

        $total_login_today = AttendedModel::where('login_year' , '=',date('Y'))->
        where('login_month' , '=',date('n'))->
        where('login_date' , '=',date('j'))->
        where('user_id' , '=',\Auth::user()->id)->
        exists();

        if($total_login_today){
            return response()->json([
                'status'=>'failed',
                'message'=>'You Have already attended today.'
            ]);
        }

        $data = new AttendedModel();
        $data->user_id = \Auth::user()->id;
        $data->login_year = date("Y");
        $data->login_month = date('n');
        $data->login_date = date('j');
        $data->login_time = date('Y-m-d H:i:s');
        $data->login_lat = $request->txt_lat;
        $data->login_lng = $request->txt_lng;
        if($data->save()){
            return response()->json([
                'status'=>'success',
                'message'=>'Welcome '  . \Auth::user()->name
            ]);
        }else{
            return response()->json([
                'status'=>'failed',
                'message'=>'Something wrong!'
            ]);
        }

    }

    public function employOut(Request $request) {
        $tot_login_today = AttendedModel::where('login_year' , '=',date('Y'))->
        where('login_month' , '=',date('n'))->
        where('login_date' , '=',date('j'))->
        where('user_id' , '=',\Auth::user()->id);

        $total_signout_today = AttendedModel::where('signout_year' , '=',date('Y'))->
        where('signout_month' , '=',date('n'))->
        where('signout_date' , '=',date('j'))->
        where('user_id' , '=',\Auth::user()->id)->
        exists();

        if(!$tot_login_today->exists()){
            return response()->json([
                'status'=>'failed',
                'message'=>'You are not Attended in today, please click <b>In</b> to Attended.'
            ]);
        }elseif ($total_signout_today){
            return response()->json([
                'status'=>'failed',
                'message'=>'You are Attended out today, thanks.'
            ]);
        }

        $update = $tot_login_today->first();
        $update->signout_year = date("Y");
        $update->signout_month = date('n');
        $update->signout_date = date('j');
        //$update->signout_time = "2020-12-20 19:00:00";
        $update->signout_time = date('Y-m-d H:i:s');
        $update->signout_lat = $request->txt_lat;
        $update->signout_lng = $request->txt_lng;
        if($update->save()){
            return response()->json([
                'status'=>'success',
                'message'=>'Yayy, go to home :) '
            ]);
        }else{
            return response()->json([
                'status'=>'failed',
                'message'=>'Something wrong!'
            ]);
        }
    }
}
